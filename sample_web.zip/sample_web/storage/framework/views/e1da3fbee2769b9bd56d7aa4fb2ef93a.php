<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</head>
<body>
    <?php if(Session::has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(Session::get('success')); ?>

                </div>
    <?php endif; ?>
    <form action="<?php echo e(url('/')); ?>/register" method="post">
    <?php echo csrf_field(); ?>
    <?php
        $demo = 1;
    ?>
    <div class="container">
        <h1 class="text-center">Registration</h1>   
        <div class="form-group">
            <label for="">Name</label>
            <input type="name" name="name" id="" class="form-control" placeholder=""/>
        </div>
        <div class="form-group">
            <label for="">Email</label>
            <input type="email" name="email" id="" class="form-control" placeholder=""/>
        </div>
        <div class="form-group">
            <label for="">Password</label>
            <input type="password" name="password" id="" class="form-control" placeholder=""/>
        </div>
        <div class="form-group">
            <label for="">Password Confirmation</label>
            <input type="password" name="password_confirmation" id="" class="form-control" placeholder=""/>
        </div>
        <button class="btn btn-primary">
            Submit
        </button>
    </div>
    </form>
</body>
</html><?php /**PATH /Users/rakibulnasib/laravel_projects/sample_web/resources/views/register.blade.php ENDPATH**/ ?>